# AidenLib

This is a simple package with a couple common methods I use when using discord.py.
